from django.urls import path
from . import views

urlpatterns = [
    path('', views.rcphome, name='rcphome'),
]
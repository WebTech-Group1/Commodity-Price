from django.http import HttpResponse
from django.template import loader

def rcphome(request):
  template = loader.get_template('rcphome.html')
  return HttpResponse(template.render())

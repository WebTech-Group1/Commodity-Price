from django.apps import AppConfig


class RcphomeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rcphome'

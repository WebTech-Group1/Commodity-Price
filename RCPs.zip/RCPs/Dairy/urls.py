from django.urls import path
from . import views

urlpatterns = [
    path('', views.Dairy, name='Dairy'),
    path('adddairy/', views.adddairy, name='adddairy'),
    path('adddairy/addrecord/', views.addrecord, name='addrecord'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('dairyupdate/<int:id>', views.dairyupdate, name='dairyupdate'),
    path('dairyupdate/updaterecord/<int:id>', views.updaterecord, name='updaterecord'),
]
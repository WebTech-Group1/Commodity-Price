from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import dairytable

def Dairy(request):
  mydairy = dairytable.objects.all().values()
  template = loader.get_template('dairy.html')
  context = {
    'mydairy': mydairy,
  }
  return HttpResponse(template.render(context, request))

def adddairy(request):
  template = loader.get_template('adddairy.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  u = request.POST['dairyname']
  v = request.POST['dairyunit']
  w = request.POST['dairyprice']
  x = request.POST['dairydistrict']
  y = request.POST['dairyprovince']
  Dairy = dairytable(dairy_name=u, dairy_unit=v, dairy_price=w, dairy_district=x,dairy_province=y)
  Dairy.save()  
  return HttpResponseRedirect(reverse('Dairy'))

def delete(request, id):
  Dairy = dairytable.objects.get(id=id)
  Dairy.delete()
  return HttpResponseRedirect(reverse('Dairy'))

def dairyupdate(request, id):
  mydairy = dairytable.objects.get(id=id)
  template = loader.get_template('dairyupdate.html')
  context = {
    'mydairy': mydairy,
  }
  return HttpResponse(template.render(context, request))

def updaterecord(request, id):
  dairyname = request.POST['dairyname']
  dairyunit = request.POST['dairyunit']
  dairyprice = request.POST['dairyprice']
  dairydistrict = request.POST['dairydistrict']
  dairyprovince = request.POST['dairyprovince']
  Dairy = dairytable.objects.get(id=id)

  Dairy.dairy_name = dairyname
  Dairy.dairy_unit = dairyunit
  Dairy.dairy_price = dairyprice
  Dairy.dairy_district = dairydistrict
  Dairy.dairy_province = dairyprovince
  Dairy.save()
  return HttpResponseRedirect(reverse('Dairy'))

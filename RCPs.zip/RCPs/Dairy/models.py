from django.db import models

class dairytable(models.Model):
  dairy_name = models.CharField(max_length=255)
  dairy_unit = models.DecimalField(max_digits=5, decimal_places=2)
  dairy_price = models.DecimalField(max_digits=10, decimal_places=2)
  dairy_district = models.CharField(max_length=255)
  dairy_province = models.CharField(max_length=255)
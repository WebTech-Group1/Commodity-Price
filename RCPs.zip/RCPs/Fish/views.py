from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import fishtable

def Fish(request):
  myfish = fishtable.objects.all().values()
  template = loader.get_template('Fish.html')
  context = {
    'myfish': myfish,
  }
  return HttpResponse(template.render(context, request))

def addfish(request):
  template = loader.get_template('addfish.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  u = request.POST['fishcategory']
  v = request.POST['fishbreed']
  w = request.POST['fishunit']
  x = request.POST['fishprice']
  y = request.POST['fishdistrict']
  z = request.POST['fishprovince']
  Fish = fishtable(fish_category=u, fish_breed=v, fish_unit=w, fish_price=x, fish_district=y,fish_province=z)
  Fish.save()  
  return HttpResponseRedirect(reverse('Fish'))

def delete(request, id):
  Fish = fishtable.objects.get(id=id)
  Fish.delete()
  return HttpResponseRedirect(reverse('Fish'))

def fishupdate(request, id):
  myfish = fishtable.objects.get(id=id)
  template = loader.get_template('fishupdate.html')
  context = {
    'myfish': myfish,
  }
  return HttpResponse(template.render(context, request))

def updaterecord(request, id):
  fishcategory = request.POST['fishcategory']
  fishbreed = request.POST['fishbreed']
  fishunit = request.POST['fishunit']
  fishprice = request.POST['fishprice']
  fishdistrict = request.POST['fishdistrict']
  fishprovince = request.POST['fishprovince']
  Fish = fishtable.objects.get(id=id)

  Fish.fish_category = fishcategory
  Fish.fish_breed = cropbreed
  Fish.fish_unit = cropunit
  Fish.fish_price = cropprice
  Fish.fish_district = cropdistrict
  Fish.fish_province = cropprovince
  Fish.save()
  return HttpResponseRedirect(reverse('Fish'))

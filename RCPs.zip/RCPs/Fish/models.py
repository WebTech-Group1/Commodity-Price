from django.db import models

class fishtable(models.Model):
  fish_category = models.CharField(max_length=255)
  fish_breed = models.CharField(max_length=255)
  fish_unit = models.DecimalField(max_digits=5, decimal_places=2)
  fish_price = models.DecimalField(max_digits=10, decimal_places=2)
  fish_district = models.CharField(max_length=255)
  fish_province = models.CharField(max_length=255)

from django.urls import path
from . import views

urlpatterns = [
    path('', views.Fish, name='Fish'),
    path('addfish/', views.addfish, name='addfish'),
    path('addfish/addrecord/', views.addrecord, name='addrecord'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('fishupdate/<int:id>', views.fishupdate, name='fishupdate'),
    path('fishupdate/updaterecord/<int:id>', views.updaterecord, name='updaterecord'),
]
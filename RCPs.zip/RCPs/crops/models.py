from django.db import models

class cropstable(models.Model):
  crop_category = models.CharField(max_length=255)
  crop_name = models.CharField(max_length=255)
  crop_unit = models.DecimalField(max_digits=5, decimal_places=2)
  crop_price = models.DecimalField(max_digits=10, decimal_places=2)
  crop_district = models.CharField(max_length=255)
  crop_province = models.CharField(max_length=255)
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import cropstable

def crops(request):
  mycrops = cropstable.objects.all().values()
  template = loader.get_template('crops.html')
  context = {
    'mycrops': mycrops,
  }
  return HttpResponse(template.render(context, request))

def addcrops(request):
  template = loader.get_template('addcrops.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  u = request.POST['cropcategory']
  v = request.POST['cropname']
  w = request.POST['cropunit']
  x = request.POST['cropprice']
  y = request.POST['cropdistrict']
  z = request.POST['cropprovince']
  crops = cropstable(crop_category=u, crop_name=v, crop_unit=w, crop_price=x, crop_district=y,crop_province=z)
  crops.save()  
  return HttpResponseRedirect(reverse('crops'))

def delete(request, id):
  crops = cropstable.objects.get(id=id)
  crops.delete()
  return HttpResponseRedirect(reverse('crops'))

def cropsupdate(request, id):
  mycrops = cropstable.objects.get(id=id)
  template = loader.get_template('cropsupdate.html')
  context = {
    'mycrops': mycrops,
  }
  return HttpResponse(template.render(context, request))

def updaterecord(request, id):
  cropcategory = request.POST['cropcategory']
  cropname = request.POST['cropname']
  cropunit = request.POST['cropunit']
  cropprice = request.POST['cropprice']
  cropdistrict = request.POST['cropdistrict']
  cropprovince = request.POST['cropprovince']
  crops = cropstable.objects.get(id=id)

  crops.crop_category = cropcategory
  crops.crop_name = cropname
  crops.crop_unit = cropunit
  crops.crop_price = cropprice
  crops.crop_district = cropdistrict
  crops.crop_province = cropprovince
  crops.save()
  return HttpResponseRedirect(reverse('crops'))
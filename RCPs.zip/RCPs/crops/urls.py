from django.urls import path
from . import views

urlpatterns = [
    path('', views.crops, name='crops'),
    path('addcrops/', views.addcrops, name='addcrops'),
    path('addcrops/addrecord/', views.addrecord, name='addrecord'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('cropsupdate/<int:id>', views.cropsupdate, name='cropsupdate'),
    path('cropsupdate/updaterecord/<int:id>', views.updaterecord, name='updaterecord'),
]
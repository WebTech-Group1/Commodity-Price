from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import lptable

def LP(request):
  mylp = lptable.objects.all().values()
  template = loader.get_template('livestockpoultry.html')
  context = {
    'mylp': mylp,
  }
  return HttpResponse(template.render(context, request))

def addlp(request):
  template = loader.get_template('addlp.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  u = request.POST['lpcategory']
  v = request.POST['lpbreed']
  w = request.POST['lpunit']
  x = request.POST['lpprice']
  y = request.POST['lpdistrict']
  z = request.POST['lpprovince']
  LP = lptable(lp_category=u, lp_breed=v, lp_unit=w, lp_price=x, lp_district=y,lp_province=z)
  LP.save()  
  return HttpResponseRedirect(reverse('LP'))

def delete(request, id):
  LP = lptable.objects.get(id=id)
  LP.delete()
  return HttpResponseRedirect(reverse('LP'))

def lpupdate(request, id):
  mylp = lptable.objects.get(id=id)
  template = loader.get_template('lpupdate.html')
  context = {
    'mylp': mylp,
  }
  return HttpResponse(template.render(context, request))

def updaterecord(request, id):
  lpcategory = request.POST['fishcategory']
  lpname = request.POST['lpname']
  lpunit = request.POST['lpunit']
  lpprice = request.POST['lpprice']
  lpdistrict = request.POST['lpdistrict']
  lpprovince = request.POST['lpprovince']
  Livestock_Poultry = lptable.objects.get(id=id)

  LP.LP_category = lpcategory
  LP.LP_breed = lpname
  LP.LP_unit = lpunit
  LP.LP_price = lpprice
  LP.LP_district = lpdistrict
  LP.LP_province = lpprovince
  LP.save()
  return HttpResponseRedirect(reverse('LP'))


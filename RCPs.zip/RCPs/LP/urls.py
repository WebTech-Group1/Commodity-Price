from django.urls import path
from . import views

urlpatterns = [
    path('', views.LP, name='LP'),
    path('addlp/', views.addlp, name='addlp'),
    path('addlp/addrecord/', views.addrecord, name='addrecord'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('lpupdate/<int:id>', views.lpupdate, name='lpupdate'),
    path('lpupdate/updaterecord/<int:id>', views.updaterecord, name='updaterecord'),
]